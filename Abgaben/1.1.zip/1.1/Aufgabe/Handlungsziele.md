
**1. [[Einschätzen, ob eine Datenbank die Anforderungen der Multi-User-Fähigkeit erfüllt und allfällige Anpassungen dokumentieren]].**

**2. [[Applikation entwerfen und mittels Transaktionen Multi-User-Fähigkeit sicherstellen]].**

**3. [[User Interfaces, Datenbankanpassungen und Transaktionen implementieren]].**

**4. [[Testspezifikation für funktionale und nicht-funktionale Aspekte der Multi-User-Fähigkeit definieren, Applikation testen und Tests protokollieren]].**

**5. [[Transaktionen dokumentieren und dabei auf Wartbarkeit und Nachvollziehbarkeit achten]].**

.