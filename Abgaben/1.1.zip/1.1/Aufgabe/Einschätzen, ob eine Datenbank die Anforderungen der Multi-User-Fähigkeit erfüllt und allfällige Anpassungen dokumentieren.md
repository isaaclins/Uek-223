**Handlungsnotwendige Kenntnisse:**  
1. Kennt Anforderungen an das Datenbankmanagement-System bezüglich Multi-User-Fähigkeit.  
2. Kennt Aspekte bei der Datenmodellierung, welche die Multi-User-Fähigkeit ermöglichen.