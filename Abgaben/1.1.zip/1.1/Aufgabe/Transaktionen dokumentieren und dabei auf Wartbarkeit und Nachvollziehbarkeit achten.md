**Handlungsnotwendige Kenntnisse:**  
1. Kennt Möglichkeiten zur Dokumentation von Transationen um DBMS und in der Applikation