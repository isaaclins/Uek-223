**Handlungsnotwendige Kenntnisse:**  
1. Kennt die prinzipiellen Unterschiede zwischen Geschäftsobjektmodell und relationalem Datenmodell .  
2. Kennt wichtige Architekturvarianten und -konzepte (Client/Server, Multi-Tier, Middleware, Framework, Klassenbibliothek).  
3. Kennt die Umsetzung einer objekt-relationalen Abbildung eines Geschäftsobjektmodells und deren Spezifikation mittels UML (Klassendiagramm, Sequenzdiagramm).
