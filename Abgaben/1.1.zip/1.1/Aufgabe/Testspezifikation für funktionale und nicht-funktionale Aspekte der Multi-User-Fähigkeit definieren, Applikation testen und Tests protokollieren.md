**Handlungsnotwendige Kenntnisse:**  
1. Kennt relevante Aspekte, welche bei der Testspezifikation einer Muli-User-Applikation zu berücksichtigen sind.  
2. Kennt ein Vorgehen, um nicht-funktionale Anforderungen zu testen.