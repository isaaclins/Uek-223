**Handlungsnotwendige Kenntnisse:**  
1. Kennt spezifische Elemente für die Umsetzung von Multi-User-fähigen Benutzerschnittstellen (z.B. Profil, unterschiedliche Benutzersichten, Berechtigungskonzept, usw.).  
2. Kennt Möglichkeiten ein mehrbenutzer-fähiges Rechtemanagement zu implementieren.  
3. Kennt Möglichkeiten um Transaktionen im DBMS sicherzustellen.  
4. Kennt Möglichkeiten um Transaktionen in der Applikation zu implementieren.  
5. Kennt relevante Techniken für die Implementation einer Persistenzschicht.